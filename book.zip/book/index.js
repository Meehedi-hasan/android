const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors')
const app = express();
require('./config/db');

app.use(express.json());
app.use(cors());


require('./routes/users.routes')(app);
require('./routes/book.routes')(app);
require('./routes/author.routes')(app);




app.listen(3002, () => {
    console.log(`Server is running on port 3002`);
});
