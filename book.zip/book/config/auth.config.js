module.exports = {
    secret: "medicine-secret-key"
};