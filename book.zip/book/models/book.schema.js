const mongoose = require('mongoose');
const Schema = mongoose.Schema;
const Author = require('./author.schema');  // Import the Author schema
const User = require('./user.schema');  // Import the User schema

const BookSchema = new Schema({
  title: {
    type: String,
    required: true
  },
  genre: {
    type: String,
    required: true
  },
  publishedDate: {
    type: Date,
    required: true
  },
  author: {
    type: Schema.Types.ObjectId,
    ref: 'Author',  // Reference to the Author schema
    required: true
  },
  addedBy: {
    type: Schema.Types.ObjectId,
    ref: 'User',  // Reference to the User schema
    required: true
  }
});

module.exports = mongoose.model('Book', BookSchema);
