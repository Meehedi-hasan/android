const Author = require('../models/author.schema')


exports.postAuthor = async (req, res) => {
    const { name, image, bio } = req.body;

    const user = new Author({
        name,
        image,
        bio,
    });

    try {
        const savedUser = await user.save();
        res.status(201).json(savedUser);
    } catch (err) {
        res.status(400).json({ message: err.message });
    }
}