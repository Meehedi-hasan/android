
const Book = require('../models/book.schema')


exports.getBooks = async (req, res) => {
    try {
        const books = await Book.find()
            .populate('author', 'name image')
            .populate('addedBy', 'username email');

        res.json(books);
    } catch (err) {
        res.status(500).json({ message: err.message });
    }
};

exports.postBook = async (req, res) => {
    const { title, genre, publishedDate, author, addedBy } = req.body;
  
    const book = new Book({
      title,
      genre,
      publishedDate,
      author,
      addedBy
    });
  
    try {
      const savedBook = await book.save();
      res.status(201).json(savedBook);
    } catch (err) {
      res.status(400).json({ message: err.message });
    }
  };